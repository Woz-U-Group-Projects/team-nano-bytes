module.exports.people = [
    {
      id: 3412,
      name: 'Sarah Taylor',
      username: 'sarah.taylor3',
      age: 54
    },
    {
      id: 5329,
      name: 'Clara Tabby',
      username: 'clara.tabby44',
      age: 28
    },
    {
      id: 9384,
      name: 'Trent Anderson',
      username: 'anderson_trent93',
      age: 31
    },
    {
      id: 2930,
      name: 'Jeremy Hudson',
      username: 'jerbear22',
      age: 44
    },
    {
      id: 5723,
      name: 'David Marling',
      username: 'dave.mar.ling',
      age: 23
    }
  ];